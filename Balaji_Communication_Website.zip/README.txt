BALAJI COMMUNICATION WEBSITE

Files:
- index.html
- style.css
- script.js

Before publishing, edit index.html:
1. Replace +910000000000 with the shop's real phone/WhatsApp number.
2. Replace "Add your shop address here".
3. Replace opening hours and email.
4. Replace product names/details/prices as required.

The site is responsive for mobile, tablet and desktop.
Open index.html in a browser to preview it.
